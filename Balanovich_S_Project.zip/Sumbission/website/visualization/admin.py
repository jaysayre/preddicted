from django.contrib import admin
from visualization.models import Poll

admin.site.register(Poll)

# Register your models here.
